# GET /v1/ml/soccer/matches/:matchId/context — 返回结构评审

## 真实返回 JSON 示例

- **带 form**（`?includeHistory=1`）：见 `ml-context-response.json`
- **不带 form**（默认）：见 `ml-context-response-no-history.json`

---

## 1. 模型友好 (Model-friendly)

| 点 | 现状 | 建议 |
|----|------|------|
| **标量为主** | `match` 里 score、completed、dateYmd、status 都是标量或简单对象，易做特征 | 保持 |
| **id 稳定** | `matchId`、`competitionId`、`home.id`/`away.id` 为字符串 ID，便于 join/embedding | 保持 |
| **form 已聚合** | `form.home/away` 提供 wins/draws/losses、goalsFor/Against，无需自己算 | 保持；若后续要序列特征可加 `form.home.matches` 的轻量列表 |
| **缺失可辨** | `quality.missingHistory`、`historyCountHome/Away` 明确告知历史是否不足 | 保持 |

**结论**：当前结构适合直接做表格特征或简单向量特征，模型友好。

---

## 2. 扁平度 (Flat enough)

| 点 | 现状 | 建议 |
|----|------|------|
| **层级** | 顶层 `data` 下 4–5 个 key：match, competition, teams, form?, quality。再往下一层即到字段。 | 已足够扁，无需再压平 |
| **match** | `match.homeTeam`/`awayTeam` 各 4 个字段，嵌套一层合理，避免重复写 home_/away_ 前缀 | 保持 |
| **teams** | `teams.home`/`away` 与 `match.homeTeam`/`awayTeam` 部分重复（id/name/abbr） | 见下方「冗余」 |
| **form** | `form.home/away` 下聚合值 + `matches[]` 数组，数组仅在有历史时用 | 保持；若模型只用聚合可考虑 `?form=summary` 只返回 wins/draws/goals |

**结论**：整体扁平度够用，不必强行全部压成一层。

---

## 3. 冗余 (Redundancy)

| 冗余 | 说明 | 建议 |
|------|------|------|
| **teams vs match** | `teams.home` 与 `match.homeTeam` 在 id/name/abbr 上重复；score 只在 match 里。 | **可接受**：teams 是「双方元信息」，match 是「本场结果」；若严格去重可只保留 `match`，用 `match.homeTeam`/`awayTeam` 同时当 identity + score，teams 可删或改为仅 `teams: { homeId, awayId }`。 |
| **competitionId** | 出现在 `match.competitionId` 和 `competition.competitionId`。 | 保留一处即可，通常留 `competition.competitionId`，match 里可删（或保留便于单表特征）。 |
| **form.matches[]** | 与 wins/draws/losses 可互推。 | 保留：序列模型可能需要时间序；若只做汇总可后续加 `?form=summary` 不返回 matches。 |

**结论**：冗余在可接受范围；若希望极简，可只保留 match + competition + quality，teams 从 match 推导，form 只保留聚合。

---

## 4. Future-proof

| 扩展点 | 现状 | 建议 |
|--------|------|------|
| **更多特征** | 目前无 xG、shots、odds。 | 在 `data` 下加可选块即可，例如 `data.xg`、`data.shots`、`data.odds`（默认 null 或省略），不破坏现有字段。 |
| **多联赛/赛季** | 已有 `competitionId`、`tier`。 | 后续若有 season 可加 `competition.season` 或 `match.season`. |
| **form 粒度** | 当前同 competition + 同 season 窗口。 | 可加 query：`?formWindow=5` 或 `?formCompetition=all`，响应里已有 `lastN`，扩展容易。 |
| **quality 扩展** | 目前 missingHistory、historyCount、dataAgeSec。 | 可加 `quality.shotsCount`、`quality.hasOdds` 等布尔/计数，便于过滤或加权。 |
| **版本** | 无 API 版本在 path 里。 | 已有 `/v1/`，后续 v2 可新 path，旧响应结构可冻结。 |

**结论**：结构便于加块状扩展（xg、shots、odds、season、form 参数），且不破坏现有客户端。

---

## 5. 可选精简版（若追求极简）

若希望「更扁、更少冗余」可做一版精简响应（例如 `?format=minimal`）：

- 只保留：`match`（含 homeTeam/awayTeam 的 id/name/abbr/score）、`competitionId`、`dateYmd`、`quality`。
- 去掉顶层 `teams`（由 match 推导）。
- form 只保留 `formHome: { wins, draws, losses, goalsFor, goalsAgainst }` 与 `formAway` 同级，不返回 `matches[]`。

当前实现保留一定冗余是为了可读性和不同模型需求（有的要序列、有的只要汇总），在「模型友好、扁平度、冗余、future-proof」之间已经做了折中；若你更倾向极简，可以按上面加一个 `format=minimal` 分支。
