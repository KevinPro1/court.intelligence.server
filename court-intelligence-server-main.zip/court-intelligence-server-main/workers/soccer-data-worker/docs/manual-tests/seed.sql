-- Seed soccer_data for manual API validation (no ESPN calls).
-- Run: wrangler d1 execute soccer_data --local --file=docs/manual-tests/seed.sql

INSERT OR REPLACE INTO soccer_competitions (competition_id, name, tier, active, created_at)
VALUES
  ('eng.1', 'Premier League', 'domestic', 1, strftime('%s', 'now')),
  ('uefa.champions', 'UEFA Champions League', 'international', 1, strftime('%s', 'now'));

INSERT OR REPLACE INTO soccer_teams (team_id, name, abbr, logo, updated_at)
VALUES
  ('359', 'Arsenal', 'ARS', 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png', strftime('%s', 'now')),
  ('375', 'Leicester City', 'LEI', 'https://a.espncdn.com/i/teamlogos/soccer/500/375.png', strftime('%s', 'now'));

INSERT OR REPLACE INTO soccer_matches_current (
  match_id, competition_id, date_ymd, start_time_utc, status, completed,
  home_team_id, home_team_name, home_team_abbr, home_score,
  away_team_id, away_team_name, away_team_abbr, away_score,
  venue_name, neutral_site, updated_at
)
VALUES (
  '704520', 'eng.1', '20250215', '2025-02-15T12:30:00.000Z', 'FT', 1,
  '375', 'Leicester City', 'LEI', 0,
  '359', 'Arsenal', 'ARS', 2,
  'King Power Stadium', 0, strftime('%s', 'now')
);

INSERT INTO soccer_matches_snapshot (match_id, competition_id, date_ymd, fetched_at, status, completed, home_score, away_score, raw_json)
VALUES ('704520', 'eng.1', '20250215', strftime('%s', 'now'), 'FT', 1, 0, 2, NULL);
