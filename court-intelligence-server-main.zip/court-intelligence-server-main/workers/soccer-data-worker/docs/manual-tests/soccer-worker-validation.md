# Soccer Data Worker – Manual validation

Replace `WORKER_URL` (e.g. `http://localhost:8787`) and `ADMIN_KEY` (from `.dev.vars`) in the examples below.

---

## 1. Local D1 and migrations

From `workers/soccer-data-worker`:

```bash
# Apply migrations to local D1 (database name from wrangler.toml: soccer_data)
wrangler d1 migrations apply soccer_data --local
```

The D1 binding name in the worker is `DB`; the database name is `soccer_data`.

---

## 2. Seed SQL (run against local D1 for API validation without ESPN)

Run these after migrations so you can hit the APIs without calling ESPN.

```sql
-- Competitions (2 keys)
INSERT OR REPLACE INTO soccer_competitions (competition_id, name, tier, active, created_at)
VALUES
  ('eng.1', 'Premier League', 'domestic', 1, strftime('%s', 'now')),
  ('uefa.champions', 'UEFA Champions League', 'international', 1, strftime('%s', 'now'));

-- Teams (2 teams)
INSERT OR REPLACE INTO soccer_teams (team_id, name, abbr, logo, updated_at)
VALUES
  ('359', 'Arsenal', 'ARS', 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png', strftime('%s', 'now')),
  ('375', 'Leicester City', 'LEI', 'https://a.espncdn.com/i/teamlogos/soccer/500/375.png', strftime('%s', 'now'));

-- One match (completed)
INSERT OR REPLACE INTO soccer_matches_current (
  match_id, competition_id, date_ymd, start_time_utc, status, completed,
  home_team_id, home_team_name, home_team_abbr, home_score,
  away_team_id, away_team_name, away_team_abbr, away_score,
  venue_name, neutral_site, updated_at
)
VALUES (
  '704520', 'eng.1', '20250215', '2025-02-15T12:30:00.000Z', 'FT', 1,
  '375', 'Leicester City', 'LEI', 0,
  '359', 'Arsenal', 'ARS', 2,
  'King Power Stadium', 0, strftime('%s', 'now')
);

-- One snapshot (optional, for match + latest snapshot response)
INSERT INTO soccer_matches_snapshot (match_id, competition_id, date_ymd, fetched_at, status, completed, home_score, away_score, raw_json)
VALUES ('704520', 'eng.1', '20250215', strftime('%s', 'now'), 'FT', 1, 0, 2, NULL);
```

To run against local D1 (from `workers/soccer-data-worker`):

```bash
wrangler d1 execute soccer_data --local --file=docs/manual-tests/seed.sql
```

Or use the provided `docs/manual-tests/seed.sql` file. If you prefer one-off commands:

```bash
wrangler d1 execute soccer_data --local --command "INSERT OR REPLACE INTO soccer_competitions (competition_id, name, tier, active, created_at) VALUES ('eng.1', 'Premier League', 'domestic', 1, strftime('%s', 'now'));"
# ... repeat for other inserts or use --file
```

---

## 3. Curl commands

### Health

```bash
curl -s "${WORKER_URL}/v1/health"
```

Expected: `{"ok":true,"data":{"status":"ok","service":"soccer-data-worker"},...}`

---

### Competitions (active only)

```bash
curl -s "${WORKER_URL}/v1/soccer/competitions"
```

Expected: `{"ok":true,"data":[{"competitionId":"eng.1",...},{"competitionId":"uefa.champions",...}],...}` (after seed).

---

### Matches today (all competitions; limit 200)

```bash
curl -s "${WORKER_URL}/v1/soccer/matches/today"
```

Optional filter by competition:

```bash
curl -s "${WORKER_URL}/v1/soccer/matches/today?competitionId=eng.1"
```

Expected (after seed): list including match `704520` for the seeded date. Note: “today” is computed in `SOCCER_TZ` (default America/New_York). For local testing you may need to seed a match with `date_ymd` equal to today in that timezone, or call with a date that matches your seed.

---

### Single match (current + latest snapshot meta)

```bash
curl -s "${WORKER_URL}/v1/soccer/matches/704520"
```

Expected: `{"ok":true,"data":{"current":{...},"latestSnapshot":{...}},...}`

---

### ML context (with form history)

```bash
curl -s "${WORKER_URL}/v1/ml/soccer/matches/704520/context?includeHistory=1"
```

Expected: `{"ok":true,"data":{"match":{...},"competition":{...},"teams":{...},"form":{...},"quality":{...}},...}`. Without seed history, `form` may have empty or partial history and `quality.missingHistory` may be true.

---

### Admin: force scoreboard refresh

```bash
curl -s -X POST "${WORKER_URL}/v1/admin/soccer/refresh" \
  -H "X-ADMIN-KEY: ${ADMIN_KEY}"
```

Expected: `{"ok":true,"data":{"dateYmd":"...","competitionsCount":N,...},...}` (calls ESPN).

---

### Admin: diagnostics state

```bash
curl -s "${WORKER_URL}/v1/admin/soccer/diagnostics/state" \
  -H "X-ADMIN-KEY: ${ADMIN_KEY}"
```

Expected: `{"ok":true,"data":{...soccer_refresh_state...},...}`

---

### Admin: recent cron runs

```bash
curl -s "${WORKER_URL}/v1/admin/soccer/diagnostics/recent?limit=20" \
  -H "X-ADMIN-KEY: ${ADMIN_KEY}"
```

Expected: `{"ok":true,"data":{"cronRuns":[...]},...}`

---

## 4. Summary

| Step | Command / action |
|------|-------------------|
| Migrations | `wrangler d1 migrations apply soccer_data --local` |
| Seed | Run seed SQL above (e.g. `wrangler d1 execute soccer_data --local --file=seed.sql`) |
| Health | `GET /v1/health` |
| Competitions | `GET /v1/soccer/competitions` |
| Matches today | `GET /v1/soccer/matches/today` or `?competitionId=eng.1` |
| Match by id | `GET /v1/soccer/matches/704520` |
| ML context | `GET /v1/ml/soccer/matches/704520/context?includeHistory=1` |
| Admin refresh | `POST /v1/admin/soccer/refresh` + `X-ADMIN-KEY` |
| Admin state | `GET /v1/admin/soccer/diagnostics/state` + `X-ADMIN-KEY` |
| Admin recent | `GET /v1/admin/soccer/diagnostics/recent?limit=20` + `X-ADMIN-KEY` |
