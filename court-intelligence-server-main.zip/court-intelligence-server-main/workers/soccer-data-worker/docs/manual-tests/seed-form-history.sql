-- Seed multiple matches so form history is non-empty for ML context (no ESPN).
-- Run: wrangler d1 execute soccer_data --local --file=docs/manual-tests/seed-form-history.sql

INSERT OR REPLACE INTO soccer_matches_current (match_id, competition_id, date_ymd, start_time_utc, status, completed, home_team_id, home_team_name, home_team_abbr, home_score, away_team_id, away_team_name, away_team_abbr, away_score, venue_name, neutral_site, updated_at)
VALUES
  ('704520', 'eng.1', '20250215', '2025-02-15T12:30:00.000Z', 'FT', 1, '375', 'Leicester City', 'LEI', 0, '359', 'Arsenal', 'ARS', 2, 'King Power Stadium', 0, strftime('%s', 'now')),
  ('704519', 'eng.1', '20250208', '2025-02-08T14:00:00.000Z', 'FT', 1, '359', 'Arsenal', 'ARS', 2, '380', 'Wolves', 'WOL', 1, 'Emirates Stadium', 0, strftime('%s', 'now')),
  ('704518', 'eng.1', '20250201', '2025-02-01T15:00:00.000Z', 'FT', 1, '375', 'Leicester City', 'LEI', 1, '367', 'Spurs', 'TOT', 2, 'King Power Stadium', 0, strftime('%s', 'now'));
