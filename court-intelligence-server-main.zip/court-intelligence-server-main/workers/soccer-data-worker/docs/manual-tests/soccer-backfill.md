# Soccer Data Worker – Backfill manual validation

Use backfill so that `/v1/ml/soccer/matches/:matchId/context?includeHistory=1` returns non-empty form history.

## Prerequisites

- Local dev: `npx wrangler dev --local` (or `--persist-to .wrangler/state` if your wrangler supports it)
- Migrations applied: `npm run db:migrate:local` (or `wrangler d1 migrations apply soccer_data --local`)
- Set `ADMIN_KEY` in `.dev.vars` (e.g. `ADMIN_KEY=change-me-in-production`)

---

## 1. Start local dev

```bash
cd workers/soccer-data-worker
npx wrangler dev --local
```

Use `http://127.0.0.1:8787` as base URL.

---

## 2. Run admin refresh (today’s scoreboard)

```bash
curl -X POST "http://127.0.0.1:8787/v1/admin/soccer/refresh" \
  -H "X-ADMIN-KEY: change-me-in-production"
```

Expected: `{"ok":true,"data":{"dateYmd":"...","competitionsCount":N,...},...}`

---

## 3. Run backfill (last 30 days, one competition)

```bash
curl -X POST "http://127.0.0.1:8787/v1/admin/soccer/backfill?days=30&competitionId=eng.1" \
  -H "X-ADMIN-KEY: change-me-in-production"
```

Optional: backfill all competitions (omit `competitionId`):

```bash
curl -X POST "http://127.0.0.1:8787/v1/admin/soccer/backfill?days=30" \
  -H "X-ADMIN-KEY: change-me-in-production"
```

Expected: `{"ok":true,"data":{"days":30,"competitionsCount":1,"matchesUpserted":N,"snapshotsInserted":N,"teamsUpserted":N},...}`

---

## 4. Pick a matchId

**Option A – from API (today’s matches)**

```bash
curl -s "http://127.0.0.1:8787/v1/soccer/matches/today?competitionId=eng.1" | jq '.data[0].matchId'
```

**Option B – from D1 (recent matches)**

```bash
npx wrangler d1 execute soccer_data --local --command "SELECT match_id, date_ymd, competition_id, home_team_id, away_team_id FROM soccer_matches_current WHERE competition_id='eng.1' ORDER BY date_ymd DESC LIMIT 5;"
```

Set `<MATCH_ID>` to one of the returned `match_id` values.

---

## 5. Validate ML context has non-empty form

```bash
curl -s "http://127.0.0.1:8787/v1/ml/soccer/matches/<MATCH_ID>/context?includeHistory=1" | jq
```

**Expected**

- `form.home.matches.length > 0` or `form.away.matches.length > 0` when that team has prior games in the same competition.
- `quality.missingHistory` is `false` when both sides have at least one historical match.

Example check:

```bash
curl -s "http://127.0.0.1:8787/v1/ml/soccer/matches/<MATCH_ID>/context?includeHistory=1" | jq '.data.form.home.matches | length, .data.quality.missingHistory'
```

---

## 6. SQL seed (form history without ESPN)

To test “form history query returns > 0 when matches exist” without running backfill, seed multiple matches for the same teams:

```bash
wrangler d1 execute soccer_data --local --file=docs/manual-tests/seed-form-history.sql
```

See `docs/manual-tests/seed-form-history.sql` for the INSERTs (704520, 704519, 704518 so Arsenal and Leicester have prior games).

Then call:

```bash
curl -s "http://127.0.0.1:8787/v1/ml/soccer/matches/704520/context?includeHistory=1" | jq '.data.form'
```

You should see `form.home.matches` and/or `form.away.matches` with length > 0 for teams 375 and 359.

---

## 7. Backfill to a specific end date (endYmd)

To backfill **from a historical end date backwards** (e.g. so a match on 2025-02-15 has prior days of data for form history), use the `endYmd` query parameter. This fills the N days ending on `endYmd` instead of “today”.

**1) Backfill 120 days ending on 2025-02-15 (e.g. for match 704520 on that date):**

```bash
curl -X POST "http://127.0.0.1:8787/v1/admin/soccer/backfill?days=120&competitionId=eng.1&endYmd=20250215" \
  -H "X-ADMIN-KEY: change-me-in-production"
```

**2) Get match details:**

```bash
curl "http://127.0.0.1:8787/v1/soccer/matches/704520"
```

**3) ML context (form.matches should be non-empty, missingHistory more likely false):**

```bash
curl "http://127.0.0.1:8787/v1/ml/soccer/matches/704520/context?includeHistory=1"
```
