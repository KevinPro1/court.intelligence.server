# Soccer Data Worker

Cloudflare Worker for ESPN soccer data: scoreboard, match summary, shots, team features, ML context API, and pregame model-call tracking. Mirrors patterns from `nba-data-worker`.

## Stack

- **Runtime**: Cloudflare Workers
- **DB**: D1 (SQLite)
- **Router**: itty-router
- **Tests**: Vitest

## Local dev

1. Copy `.dev.vars.example` to `.dev.vars` and set `ADMIN_KEY`.
2. Create local D1 and run migrations:
   ```bash
   npm run db:migrate:local
   ```
3. Start dev server:
   ```bash
   npm run dev
   ```
4. Use `http://localhost:8787` as `WORKER_URL` in manual tests.

## Deploy

1. Create a D1 database (dashboard or `wrangler d1 create soccer_data`) and set `database_id` in `wrangler.toml`.
2. Run migrations on remote:
   ```bash
   npm run db:migrate
   ```
3. Deploy:
   ```bash
   npm run deploy
   ```

## Config

- **ESPN_BASE_URL**: `https://site.api.espn.com/apis/site/v2/sports/soccer`
- **SOCCER_LEAGUE**: default `eng.1` (Premier League); configurable in `wrangler.toml` or env.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/v1/health` | Health check |
| GET | `/v1/soccer/matches/today?date=YYYYMMDD` | Matches for date (Eastern) |
| GET | `/v1/soccer/matches/:matchId` | Single match |
| GET | `/v1/soccer/matches/:matchId/shots` | Shots for match |
| GET | `/v1/ml/soccer/matches/:matchId/context?includeOdds=1&includePast=1` | ML context |
| POST | `/v1/admin/sync?date=YYYYMMDD` | Admin: fetch scoreboard + sync all matches |
| POST | `/v1/admin/matches/:matchId/sync` | Admin: sync one match |
| POST | `/v1/model-calls/soccer/pregame` | Admin: record pregame prediction |
| POST | `/v1/matches/:matchId/finalize` | Admin: settle pregame calls |

Admin routes require header `X-ADMIN-KEY` matching `ADMIN_KEY`.

## Manual tests

See [docs/manual-tests/soccer-worker-validation.md](docs/manual-tests/soccer-worker-validation.md) for curl examples.

## Scripts

- `npm run dev` – wrangler dev (D1 local)
- `npm run typecheck` – tsc --noEmit
- `npm test` – vitest run (date utils + timezone tests)
