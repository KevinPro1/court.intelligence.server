-- Soccer Data Worker - indexes

-- soccer_matches_current
CREATE INDEX IF NOT EXISTS idx_soccer_matches_current_competition_date ON soccer_matches_current(competition_id, date_ymd);
CREATE INDEX IF NOT EXISTS idx_soccer_matches_current_date ON soccer_matches_current(date_ymd);
CREATE INDEX IF NOT EXISTS idx_soccer_matches_current_updated ON soccer_matches_current(updated_at);

-- soccer_matches_snapshot
CREATE INDEX IF NOT EXISTS idx_soccer_matches_snapshot_match_fetched ON soccer_matches_snapshot(match_id, fetched_at);

-- soccer_error_log
CREATE INDEX IF NOT EXISTS idx_soccer_error_log_created ON soccer_error_log(created_at DESC);

-- soccer_cron_runs (for diagnostics)
CREATE INDEX IF NOT EXISTS idx_soccer_cron_runs_started ON soccer_cron_runs(started_at DESC);
