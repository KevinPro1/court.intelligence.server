-- Soccer Data Worker - base tables (multi-competition)
-- 1) soccer_refresh_state (singleton)
CREATE TABLE IF NOT EXISTS soccer_refresh_state (
  key TEXT PRIMARY KEY,
  last_scoreboard_fetch_at INTEGER,
  last_error TEXT,
  lock_until INTEGER,
  lock_token TEXT,
  updated_at INTEGER NOT NULL
);

INSERT OR IGNORE INTO soccer_refresh_state (key, updated_at) VALUES ('singleton', 0);

-- 2) soccer_competitions
CREATE TABLE IF NOT EXISTS soccer_competitions (
  competition_id TEXT PRIMARY KEY,
  name TEXT,
  tier TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);

-- 3) soccer_teams
CREATE TABLE IF NOT EXISTS soccer_teams (
  team_id TEXT PRIMARY KEY,
  name TEXT,
  abbr TEXT,
  logo TEXT,
  updated_at INTEGER NOT NULL
);

-- 4) soccer_matches_current
CREATE TABLE IF NOT EXISTS soccer_matches_current (
  match_id TEXT PRIMARY KEY,
  competition_id TEXT NOT NULL,
  date_ymd TEXT NOT NULL,
  start_time_utc TEXT,
  status TEXT,
  completed INTEGER NOT NULL DEFAULT 0,
  home_team_id TEXT,
  home_team_name TEXT,
  home_team_abbr TEXT,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_team_id TEXT,
  away_team_name TEXT,
  away_team_abbr TEXT,
  away_score INTEGER NOT NULL DEFAULT 0,
  venue_name TEXT,
  neutral_site INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

-- 5) soccer_matches_snapshot (append-only)
CREATE TABLE IF NOT EXISTS soccer_matches_snapshot (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id TEXT NOT NULL,
  competition_id TEXT,
  date_ymd TEXT,
  fetched_at INTEGER NOT NULL,
  status TEXT,
  completed INTEGER,
  home_score INTEGER,
  away_score INTEGER,
  raw_json TEXT
);

-- 6) soccer_error_log
CREATE TABLE IF NOT EXISTS soccer_error_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL,
  ref_id TEXT,
  message TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

-- 7) soccer_cron_runs
CREATE TABLE IF NOT EXISTS soccer_cron_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cron TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  ok INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  competitions_count INTEGER DEFAULT 0,
  matches_upserted INTEGER DEFAULT 0,
  snapshots_inserted INTEGER DEFAULT 0,
  teams_upserted INTEGER DEFAULT 0
);
