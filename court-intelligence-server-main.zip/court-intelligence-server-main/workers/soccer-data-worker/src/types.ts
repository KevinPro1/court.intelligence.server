/**
 * Shared types for Soccer Data Worker (multi-competition).
 */

export interface Env {
  DB: D1Database;
  ADMIN_KEY: string;
  ESPN_SOCCER_BASE_URL: string;
  SOCCER_COMPETITIONS?: string;
  SOCCER_TZ?: string;
  SOCCER_SNAPSHOT_DAYS?: string;
  SOCCER_BACKFILL_DAYS?: string;
  SOCCER_BACKFILL_END_YMD?: string; // CHANGED: optional YYYYMMDD backfill end date (cron only)
  SOCCER_INGEST_YESTERDAY?: string;
  DEBUG_SNAPSHOT?: string;
}

/** Normalized match from scoreboard (with competition + venue). */
export interface NormalizedSoccerMatch {
  matchId: string;
  competitionId: string;
  dateYmd: string;
  startTimeUtc: string | null;
  status: string;
  completed: boolean;
  homeTeam: { id: string; name: string; abbr: string; score: number };
  awayTeam: { id: string; name: string; abbr: string; score: number };
  venueName: string | null;
  neutralSite: boolean;
}

/** Minimal team identity from ESPN. */
export interface NormalizedSoccerTeam {
  teamId: string;
  name: string;
  abbr: string;
  logo: string | null;
}

/** Competition row. */
export interface SoccerCompetitionRow {
  competition_id: string;
  name: string | null;
  tier: string | null;
  active: number;
  created_at: number;
}

/** Match current row. */
export interface SoccerMatchCurrentRow {
  match_id: string;
  competition_id: string;
  date_ymd: string;
  start_time_utc: string | null;
  status: string | null;
  completed: number;
  home_team_id: string | null;
  home_team_name: string | null;
  home_team_abbr: string | null;
  home_score: number;
  away_team_id: string | null;
  away_team_name: string | null;
  away_team_abbr: string | null;
  away_score: number;
  venue_name: string | null;
  neutral_site: number;
  updated_at: number;
}

/** API response meta. */
export interface ApiMeta {
  serverTimeUtc: string;
  source: string;
  cacheHit?: boolean;
}

/** Form summary for one team (last N matches). */
export interface TeamFormSummary {
  teamId: string;
  competitionId: string;
  lastN: number;
  wins: number;
  draws: number;
  losses: number;
  goalsFor: number;
  goalsAgainst: number;
  matches: Array<{
    matchId: string;
    dateYmd: string;
    homeTeamId: string;
    awayTeamId: string;
    teamScore: number;
    oppScore: number;
    isHome: number;
  }>;
}
