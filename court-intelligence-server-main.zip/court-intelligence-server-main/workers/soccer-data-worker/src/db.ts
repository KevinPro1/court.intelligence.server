/**
 * D1 query helpers for Soccer Data Worker (multi-competition).
 * All timestamps in Unix seconds (integer).
 */

import type { NormalizedSoccerMatch, SoccerMatchCurrentRow, TeamFormSummary } from "./types";

const now = () => Math.floor(Date.now() / 1000);
const CRON_LOCK_TTL_SEC = 110;
const SINGLETON_KEY = "singleton";

// --- soccer_refresh_state ---

export interface SoccerRefreshStateRow {
  key: string;
  last_scoreboard_fetch_at: number | null;
  last_error: string | null;
  lock_until: number | null;
  lock_token: string | null;
  updated_at: number;
}

export async function getSoccerRefreshState(db: D1Database): Promise<SoccerRefreshStateRow | null> {
  const row = await db
    .prepare("SELECT * FROM soccer_refresh_state WHERE key = ?")
    .bind(SINGLETON_KEY)
    .first<SoccerRefreshStateRow>();
  return row ?? null;
}

export async function acquireSoccerCronLock(
  db: D1Database,
  ttlSeconds: number = CRON_LOCK_TTL_SEC
): Promise<{ acquired: boolean }> {
  const ts = now();
  const lockUntil = ts + ttlSeconds;
  const r = await db
    .prepare(
      `UPDATE soccer_refresh_state SET lock_until = ?, updated_at = ? WHERE key = ? AND (lock_until IS NULL OR lock_until <= ?)`
    )
    .bind(lockUntil, ts, SINGLETON_KEY, ts)
    .run();
  const acquired = (r.meta.changes ?? 0) === 1;
  return { acquired };
}

export async function releaseSoccerCronLock(db: D1Database): Promise<void> {
  await db
    .prepare(`UPDATE soccer_refresh_state SET lock_until = NULL, updated_at = ? WHERE key = ?`)
    .bind(now(), SINGLETON_KEY)
    .run();
}

export async function updateSoccerRefreshState(
  db: D1Database,
  updates: { last_scoreboard_fetch_at?: number | null; last_error?: string | null }
): Promise<void> {
  const state = await getSoccerRefreshState(db);
  const ts = now();
  const last_scoreboard_fetch_at = updates.last_scoreboard_fetch_at ?? state?.last_scoreboard_fetch_at ?? null;
  const last_error = updates.last_error !== undefined ? updates.last_error : state?.last_error ?? null;
  await db
    .prepare(
      `UPDATE soccer_refresh_state SET last_scoreboard_fetch_at = ?, last_error = ?, updated_at = ? WHERE key = ?`
    )
    .bind(last_scoreboard_fetch_at, last_error, ts, SINGLETON_KEY)
    .run();
}

// --- soccer_competitions ---

export async function upsertSoccerCompetitions(
  db: D1Database,
  rows: Array<{ competition_id: string; name: string | null; tier: string | null; active: number }>
): Promise<void> {
  if (rows.length === 0) return;
  const ts = now();
  const stmt = db.prepare(
    `INSERT INTO soccer_competitions (competition_id, name, tier, active, created_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(competition_id) DO UPDATE SET name = excluded.name, tier = excluded.tier, active = excluded.active`
  );
  const batch = rows.map((r) =>
    stmt.bind(r.competition_id, r.name ?? null, r.tier ?? null, r.active ?? 1, ts)
  );
  await db.batch(batch);
}

export async function getSoccerCompetitionsActive(db: D1Database): Promise<Array<{ competition_id: string; name: string | null; tier: string | null; active: number }>> {
  const { results } = await db
    .prepare("SELECT competition_id, name, tier, active FROM soccer_competitions WHERE active = 1 ORDER BY competition_id")
    .all<{ competition_id: string; name: string | null; tier: string | null; active: number }>();
  return results ?? [];
}

// --- soccer_teams ---

export async function upsertSoccerTeamsBatch(
  db: D1Database,
  rows: Array<{ team_id: string; name: string; abbr: string; logo: string | null }>
): Promise<void> {
  if (rows.length === 0) return;
  const ts = now();
  const stmt = db.prepare(
    `INSERT INTO soccer_teams (team_id, name, abbr, logo, updated_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(team_id) DO UPDATE SET name = excluded.name, abbr = excluded.abbr, logo = excluded.logo, updated_at = excluded.updated_at`
  );
  const batch = rows.map((r) =>
    stmt.bind(r.team_id, r.name, r.abbr ?? r.team_id, r.logo ?? null, ts)
  );
  await db.batch(batch);
}

// --- soccer_matches_current ---

type MatchCurrentInput = {
  match_id: string;
  competition_id: string;
  date_ymd: string;
  start_time_utc?: string | null;
  status?: string | null;
  completed: number;
  home_team_id: string;
  home_team_name?: string | null;
  home_team_abbr?: string | null;
  home_score: number;
  away_team_id: string;
  away_team_name?: string | null;
  away_team_abbr?: string | null;
  away_score: number;
  venue_name?: string | null;
  neutral_site?: number;
};

const upsertMatchCurrentSql = `INSERT INTO soccer_matches_current (
  match_id, competition_id, date_ymd, start_time_utc, status, completed,
  home_team_id, home_team_name, home_team_abbr, home_score,
  away_team_id, away_team_name, away_team_abbr, away_score,
  venue_name, neutral_site, updated_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(match_id) DO UPDATE SET
  competition_id = excluded.competition_id,
  date_ymd = excluded.date_ymd,
  start_time_utc = excluded.start_time_utc,
  status = excluded.status,
  completed = excluded.completed,
  home_team_id = excluded.home_team_id,
  home_team_name = excluded.home_team_name,
  home_team_abbr = excluded.home_team_abbr,
  home_score = excluded.home_score,
  away_team_id = excluded.away_team_id,
  away_team_name = excluded.away_team_name,
  away_team_abbr = excluded.away_team_abbr,
  away_score = excluded.away_score,
  venue_name = excluded.venue_name,
  neutral_site = excluded.neutral_site,
  updated_at = excluded.updated_at`;

export async function upsertSoccerMatchesCurrent(
  db: D1Database,
  matches: MatchCurrentInput[]
): Promise<void> {
  if (matches.length === 0) return;
  const ts = now();
  const stmt = db.prepare(upsertMatchCurrentSql);
  const batch = matches.map((m) =>
    stmt.bind(
      m.match_id,
      m.competition_id,
      m.date_ymd,
      m.start_time_utc ?? null,
      m.status ?? null,
      m.completed ?? 0,
      m.home_team_id,
      m.home_team_name ?? null,
      m.home_team_abbr ?? null,
      m.home_score ?? 0,
      m.away_team_id,
      m.away_team_name ?? null,
      m.away_team_abbr ?? null,
      m.away_score ?? 0,
      m.venue_name ?? null,
      m.neutral_site ?? 0,
      ts
    )
  );
  await db.batch(batch);
}

// --- soccer_matches_snapshot ---

export async function insertSoccerMatchSnapshotsBatch(
  db: D1Database,
  rows: Array<{
    match_id: string;
    competition_id: string | null;
    date_ymd: string | null;
    status: string | null;
    completed: number | null;
    home_score: number | null;
    away_score: number | null;
    raw_json: string | null;
  }>
): Promise<void> {
  if (rows.length === 0) return;
  const fetchedAt = now();
  const stmt = db.prepare(
    `INSERT INTO soccer_matches_snapshot (match_id, competition_id, date_ymd, fetched_at, status, completed, home_score, away_score, raw_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const batch = rows.map((r) =>
    stmt.bind(
      r.match_id,
      r.competition_id ?? null,
      r.date_ymd ?? null,
      fetchedAt,
      r.status ?? null,
      r.completed ?? null,
      r.home_score ?? null,
      r.away_score ?? null,
      r.raw_json ?? null
    )
  );
  await db.batch(batch);
}

// --- get matches ---

export async function getSoccerMatchesByDate(
  db: D1Database,
  dateYmd: string,
  competitionId?: string | null,
  limit: number = 200
): Promise<SoccerMatchCurrentRow[]> {
  if (competitionId) {
    const { results } = await db
      .prepare("SELECT * FROM soccer_matches_current WHERE date_ymd = ? AND competition_id = ? ORDER BY start_time_utc ASC LIMIT ?")
      .bind(dateYmd, competitionId, limit)
      .all<SoccerMatchCurrentRow>();
    return results ?? [];
  }
  const { results } = await db
    .prepare("SELECT * FROM soccer_matches_current WHERE date_ymd = ? ORDER BY start_time_utc ASC LIMIT ?")
    .bind(dateYmd, limit)
    .all<SoccerMatchCurrentRow>();
  return results ?? [];
}

export async function getSoccerMatchById(db: D1Database, matchId: string): Promise<SoccerMatchCurrentRow | null> {
  const row = await db
    .prepare("SELECT * FROM soccer_matches_current WHERE match_id = ?")
    .bind(matchId)
    .first<SoccerMatchCurrentRow>();
  return row ?? null;
}

export async function getLatestSoccerSnapshot(
  db: D1Database,
  matchId: string
): Promise<{ fetched_at: number; status: string | null } | null> {
  const row = await db
    .prepare("SELECT fetched_at, status FROM soccer_matches_snapshot WHERE match_id = ? ORDER BY fetched_at DESC LIMIT 1")
    .bind(matchId)
    .first<{ fetched_at: number; status: string | null }>();
  return row ?? null;
}

// --- form: last N matches for a team in same competition ---

/**
 * Last N matches for a team (same competition, by date_ymd desc).
 * Used for form features (wins/draws/losses, goals_for/against).
 */
export async function getSoccerRecentMatchesForTeam(
  db: D1Database,
  teamId: string,
  competitionId: string,
  dateYmdBefore: string,
  limit: number = 5
): Promise<SoccerMatchCurrentRow[]> {
  const { results } = await db
    .prepare(
      `SELECT * FROM soccer_matches_current
       WHERE competition_id = ? AND date_ymd < ? AND (home_team_id = ? OR away_team_id = ?)
       ORDER BY date_ymd DESC, start_time_utc DESC LIMIT ?`
    )
    .bind(competitionId, dateYmdBefore, teamId, teamId, limit)
    .all<SoccerMatchCurrentRow>();
  return results ?? [];
}

/**
 * Build form summary for one team (last N matches).
 */
export function buildTeamFormSummary(
  teamId: string,
  competitionId: string,
  matches: SoccerMatchCurrentRow[],
  lastN: number
): TeamFormSummary {
  let wins = 0,
    draws = 0,
    losses = 0,
    goalsFor = 0,
    goalsAgainst = 0;
  const list: TeamFormSummary["matches"] = [];
  for (const m of matches) {
    const isHome = m.home_team_id === teamId ? 1 : 0;
    const teamScore = isHome ? m.home_score : m.away_score;
    const oppScore = isHome ? m.away_score : m.home_score;
    goalsFor += teamScore;
    goalsAgainst += oppScore;
    if (teamScore > oppScore) wins++;
    else if (teamScore < oppScore) losses++;
    else draws++;
    list.push({
      matchId: m.match_id,
      dateYmd: m.date_ymd,
      homeTeamId: m.home_team_id ?? "",
      awayTeamId: m.away_team_id ?? "",
      teamScore,
      oppScore,
      isHome,
    });
  }
  return {
    teamId,
    competitionId,
    lastN,
    wins,
    draws,
    losses,
    goalsFor,
    goalsAgainst,
    matches: list,
  };
}

// --- soccer_error_log ---

const ERROR_LOG_MESSAGE_MAX = 500;

export async function insertSoccerErrorLog(
  db: D1Database,
  scope: string,
  refId: string | null,
  message: string
): Promise<void> {
  const ts = now();
  const msg = message.slice(0, ERROR_LOG_MESSAGE_MAX);
  await db
    .prepare("INSERT INTO soccer_error_log (scope, ref_id, message, created_at) VALUES (?, ?, ?, ?)")
    .bind(scope, refId ?? null, msg, ts)
    .run();
}

// --- soccer_cron_runs ---

export async function insertSoccerCronRun(
  db: D1Database,
  cron: string,
  startedAt: number
): Promise<number> {
  const r = await db
    .prepare(
      "INSERT INTO soccer_cron_runs (cron, started_at, ok) VALUES (?, ?, 0)"
    )
    .bind(cron, startedAt)
    .run();
  const id = r.meta.last_row_id;
  return typeof id === "number" ? id : Number(id ?? 0);
}

export async function finishSoccerCronRun(
  db: D1Database,
  id: number,
  updates: {
    finished_at: number;
    ok: number;
    error?: string | null;
    competitions_count?: number;
    matches_upserted?: number;
    snapshots_inserted?: number;
    teams_upserted?: number;
  }
): Promise<void> {
  const {
    finished_at,
    ok,
    error = null,
    competitions_count = 0,
    matches_upserted = 0,
    snapshots_inserted = 0,
    teams_upserted = 0,
  } = updates;
  await db
    .prepare(
      `UPDATE soccer_cron_runs SET finished_at = ?, ok = ?, error = ?,
       competitions_count = ?, matches_upserted = ?, snapshots_inserted = ?, teams_upserted = ?
       WHERE id = ?`
    )
    .bind(finished_at, ok, error ?? null, competitions_count, matches_upserted, snapshots_inserted, teams_upserted, id)
    .run();
}

export interface SoccerCronRunRow {
  id: number;
  cron: string;
  started_at: number;
  finished_at: number | null;
  ok: number;
  error: string | null;
  competitions_count: number;
  matches_upserted: number;
  snapshots_inserted: number;
  teams_upserted: number;
}

export async function getSoccerCronRunsRecent(
  db: D1Database,
  limit: number = 20
): Promise<SoccerCronRunRow[]> {
  const { results } = await db
    .prepare(
      `SELECT id, cron, started_at, finished_at, ok, error,
       competitions_count, matches_upserted, snapshots_inserted, teams_upserted
       FROM soccer_cron_runs ORDER BY started_at DESC LIMIT ?`
    )
    .bind(limit)
    .all<SoccerCronRunRow>();
  return results ?? [];
}

// --- cleanup snapshots ---

export async function cleanupSoccerSnapshots(
  db: D1Database,
  retainDays: number
): Promise<number> {
  const cutoff = now() - retainDays * 86400;
  const r = await db
    .prepare("DELETE FROM soccer_matches_snapshot WHERE fetched_at < ?")
    .bind(cutoff)
    .run();
  return r.meta.changes ?? 0;
}

// --- row to normalized ---

export function soccerMatchRowToNormalized(row: SoccerMatchCurrentRow): NormalizedSoccerMatch {
  return {
    matchId: row.match_id,
    competitionId: row.competition_id,
    dateYmd: row.date_ymd,
    startTimeUtc: row.start_time_utc,
    status: row.status ?? "",
    completed: row.completed !== 0,
    homeTeam: {
      id: row.home_team_id ?? "",
      name: row.home_team_name ?? "",
      abbr: row.home_team_abbr ?? row.home_team_id ?? "",
      score: row.home_score,
    },
    awayTeam: {
      id: row.away_team_id ?? "",
      name: row.away_team_name ?? "",
      abbr: row.away_team_abbr ?? row.away_team_id ?? "",
      score: row.away_score,
    },
    venueName: row.venue_name,
    neutralSite: row.neutral_site !== 0,
  };
}
