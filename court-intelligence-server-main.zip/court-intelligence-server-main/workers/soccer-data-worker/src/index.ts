/**
 * Soccer Data Worker: multi-competition ESPN soccer scoreboard + model-friendly APIs.
 */

import { Router } from "itty-router";
import * as db from "./db";
import { jsonOk, jsonErr, jsonOkWithEtag } from "./routes/_helpers";
import {
  handleScheduled,
  runScoreboardRefresh,
  runBackfillOnce,
  getBackfillDays,
  FORM_LAST_N,
} from "./cron/sync";
import { todayYmdInTz } from "./utils/date";
import type { Env, TeamFormSummary } from "./types";

const router = Router<Request, [Env]>();

const ADMIN_HEADERS = { "Cache-Control": "no-store" as const };

function requireAdmin(request: Request, env: Env): Response | null {
  const key = request.headers.get("X-ADMIN-KEY");
  if (key !== env.ADMIN_KEY) {
    return jsonErr(request, "UNAUTHORIZED", "Unauthorized", 401, undefined, { headers: ADMIN_HEADERS });
  }
  return null;
}

// --- GET /v1/health ---
router.get("/v1/health", (_request: Request, _env: Env) => {
  return jsonOk(
    _request,
    { status: "ok", service: "soccer-data-worker" },
    undefined,
    { cacheControl: "no-store" }
  );
});

// --- GET /v1/soccer/competitions ---
router.get("/v1/soccer/competitions", async (request: Request, env: Env) => {
  const rows = await db.getSoccerCompetitionsActive(env.DB);
  const data = rows.map((r) => ({
    competitionId: r.competition_id,
    name: r.name,
    tier: r.tier,
    active: r.active,
  }));
  return jsonOkWithEtag(request, data, undefined, { cacheControl: "public, max-age=60" });
});

// --- GET /v1/soccer/matches/today?competitionId= ---
router.get("/v1/soccer/matches/today", async (request: Request, env: Env) => {
  const url = new URL(request.url);
  const competitionId = url.searchParams.get("competitionId") ?? undefined;
  const tz = env.SOCCER_TZ ?? "America/New_York";
  const dateYmd = todayYmdInTz(tz);
  const rows = await db.getSoccerMatchesByDate(env.DB, dateYmd, competitionId ?? null, 200);
  const data = rows.map(db.soccerMatchRowToNormalized);
  return jsonOkWithEtag(request, data, undefined, { cacheControl: "public, max-age=15" });
});

// --- GET /v1/soccer/matches/:matchId ---
router.get("/v1/soccer/matches/:matchId", async (request: Request, env: Env) => {
  const matchId = (request as Request & { params?: { matchId?: string } }).params?.matchId ?? "";
  const row = await db.getSoccerMatchById(env.DB, matchId);
  if (!row) {
    return jsonErr(request, "NOT_FOUND", "Match not found", 404);
  }
  const snapshot = await db.getLatestSoccerSnapshot(env.DB, matchId);
  const data = {
    current: db.soccerMatchRowToNormalized(row),
    latestSnapshot: snapshot
      ? { matchId, fetchedAt: snapshot.fetched_at, status: snapshot.status }
      : null,
  };
  return jsonOkWithEtag(request, data, undefined, { cacheControl: "public, max-age=15" });
});

// --- GET /v1/ml/soccer/matches/:matchId/context?includeHistory=1 ---
router.get("/v1/ml/soccer/matches/:matchId/context", async (request: Request, env: Env) => {
  const matchId = (request as Request & { params?: { matchId?: string } }).params?.matchId ?? "";
  const url = new URL(request.url);
  const includeHistory = url.searchParams.get("includeHistory") === "1";

  const match = await db.getSoccerMatchById(env.DB, matchId);
  if (!match) {
    return jsonErr(request, "NOT_FOUND", "Match not found", 404);
  }

  const dataAgeSec = match.updated_at
    ? Math.floor(Date.now() / 1000) - match.updated_at
    : null;

  const competition = (await db.getSoccerCompetitionsActive(env.DB)).find(
    (c) => c.competition_id === match.competition_id
  );
  const competitionMeta = competition
    ? { competitionId: competition.competition_id, name: competition.name, tier: competition.tier }
    : null;

  const teams = {
    home: {
      id: match.home_team_id,
      name: match.home_team_name,
      abbr: match.home_team_abbr,
    },
    away: {
      id: match.away_team_id,
      name: match.away_team_name,
      abbr: match.away_team_abbr,
    },
  };

  let formHome: TeamFormSummary | null = null;
  let formAway: TeamFormSummary | null = null;
  let missingHistory = false;
  let historyCountHome = 0;
  let historyCountAway = 0;

  if (includeHistory && match.home_team_id && match.away_team_id) {
    const homeMatches = await db.getSoccerRecentMatchesForTeam(
      env.DB,
      match.home_team_id,
      match.competition_id,
      match.date_ymd,
      FORM_LAST_N
    );
    const awayMatches = await db.getSoccerRecentMatchesForTeam(
      env.DB,
      match.away_team_id,
      match.competition_id,
      match.date_ymd,
      FORM_LAST_N
    );
    formHome = db.buildTeamFormSummary(
      match.home_team_id,
      match.competition_id,
      homeMatches,
      FORM_LAST_N
    );
    formAway = db.buildTeamFormSummary(
      match.away_team_id,
      match.competition_id,
      awayMatches,
      FORM_LAST_N
    );
    historyCountHome = formHome.matches.length;
    historyCountAway = formAway.matches.length;
    missingHistory = historyCountHome === 0 || historyCountAway === 0;
  }

  const quality = {
    missingHistory,
    historyCountHome,
    historyCountAway,
    dataAgeSec,
  };

  const data = {
    match: db.soccerMatchRowToNormalized(match),
    competition: competitionMeta,
    teams,
    form: includeHistory
      ? { home: formHome, away: formAway }
      : undefined,
    quality,
  };

  return jsonOkWithEtag(request, data, undefined, { cacheControl: "public, max-age=60" });
});

// --- POST /v1/admin/soccer/refresh ---
router.post("/v1/admin/soccer/refresh", async (request: Request, env: Env) => {
  const auth = requireAdmin(request, env);
  if (auth) return auth;
  try {
    const result = await runScoreboardRefresh(env);
    return jsonOk(request, result, undefined, { headers: ADMIN_HEADERS });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return jsonErr(request, "REFRESH_FAILED", msg, 502, undefined, { headers: ADMIN_HEADERS });
  }
});

// --- GET /v1/admin/soccer/diagnostics/state ---
router.get("/v1/admin/soccer/diagnostics/state", async (request: Request, env: Env) => {
  const auth = requireAdmin(request, env);
  if (auth) return auth;
  const state = await db.getSoccerRefreshState(env.DB);
  const data = state ?? {
    key: "singleton",
    last_scoreboard_fetch_at: null,
    last_error: null,
    lock_until: null,
    lock_token: null,
    updated_at: 0,
  };
  return jsonOk(request, data, undefined, { headers: ADMIN_HEADERS });
});

// --- GET /v1/admin/soccer/diagnostics/recent?limit=20 ---
router.get("/v1/admin/soccer/diagnostics/recent", async (request: Request, env: Env) => {
  const auth = requireAdmin(request, env);
  if (auth) return auth;
  const url = new URL(request.url);
  const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get("limit") ?? "20", 10) || 20));
  const rows = await db.getSoccerCronRunsRecent(env.DB, limit);
  const data = { cronRuns: rows };
  return jsonOk(request, data, undefined, { headers: ADMIN_HEADERS });
});

// --- POST /v1/admin/soccer/backfill?days=30&competitionId=eng.1&endYmd=20250215 ---
// CHANGED: optional endYmd (YYYYMMDD) to backfill from that date backwards instead of from today
router.post("/v1/admin/soccer/backfill", async (request: Request, env: Env) => {
  const auth = requireAdmin(request, env);
  if (auth) return auth;
  const url = new URL(request.url);
  const daysParam = url.searchParams.get("days");
  const days = daysParam != null && daysParam !== ""
    ? Math.max(1, Math.min(120, parseInt(daysParam, 10) || getBackfillDays(env)))
    : getBackfillDays(env);
  const competitionId = url.searchParams.get("competitionId")?.trim() || undefined;
  const endYmdRaw = url.searchParams.get("endYmd")?.trim();
  if (endYmdRaw != null && endYmdRaw !== "" && !/^\d{8}$/.test(endYmdRaw)) {
    return jsonErr(request, "BAD_REQUEST", "endYmd must be YYYYMMDD (8 digits)", 400, undefined, { headers: ADMIN_HEADERS });
  }
  const endYmd = endYmdRaw && endYmdRaw !== "" ? endYmdRaw : undefined;
  try {
    const result = await runBackfillOnce(env, days, competitionId, endYmd);
    return jsonOk(request, result, undefined, { headers: ADMIN_HEADERS });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return jsonErr(request, "BACKFILL_FAILED", msg, 502, undefined, { headers: ADMIN_HEADERS });
  }
});

// --- 404 ---
router.all("*", (request: Request) =>
  jsonErr(request, "NOT_FOUND", "Not found", 404)
);

export default {
  fetch: router.handle,
  async scheduled(event: ScheduledEvent, env: Env, _ctx: ExecutionContext): Promise<void> {
    await handleScheduled(env, event);
  },
};
