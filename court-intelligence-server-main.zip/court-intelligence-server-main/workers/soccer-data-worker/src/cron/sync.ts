/**
 * Cron sync: multi-competition scoreboard (every 2 min), competition metadata (every 6h), cleanup (daily), backfill (daily).
 * Best-effort; never throw beyond handler; error_log per competition on failure.
 */

import { fetchSoccerScoreboard, parseSoccerScoreboard } from "../espn";
import * as db from "../db";
import { todayYmdInTz, dateYmdDaysAgoInTz, dateYmdDaysAgoFromEndYmd, parseYmdToUtcDate } from "../utils/date"; // CHANGED: backfill endYmd
import type { Env } from "../types";

const CRON_LOCK_TTL_SEC = 110;
const SCOREBOARD_TIMEOUT_MS = 8000;
const BACKFILL_DELAY_MS = 80;
const FORM_LAST_N = 5;

function getCompetitionsList(env: Env): string[] {
  const raw = env.SOCCER_COMPETITIONS ?? "eng.1";
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function getTz(env: Env): string {
  return env.SOCCER_TZ ?? "America/New_York";
}

function getSnapshotDays(env: Env): number {
  const s = env.SOCCER_SNAPSHOT_DAYS;
  if (s == null || s === "") return 7;
  const n = parseInt(s, 10);
  return Number.isFinite(n) && n > 0 ? n : 7;
}

/** SOCCER_BACKFILL_DAYS: default 30, clamp 1..120. */
function getBackfillDays(env: Env): number {
  const s = env.SOCCER_BACKFILL_DAYS;
  if (s == null || s === "") return 30;
  const n = parseInt(s, 10);
  if (!Number.isFinite(n)) return 30;
  return Math.max(1, Math.min(120, n));
}

/** SOCCER_BACKFILL_END_YMD: optional YYYYMMDD to use as backfill end date; if unset or invalid, use today in TZ. */
export function getBackfillEndYmd(env: Env): string | null {
  const s = env.SOCCER_BACKFILL_END_YMD?.trim();
  if (s == null || s === "") return null;
  if (parseYmdToUtcDate(s) === null) return null;
  return s;
}

function getDebugSnapshot(env: Env): boolean {
  return env.DEBUG_SNAPSHOT === "1" || env.DEBUG_SNAPSHOT === "true";
}

function getIngestYesterday(env: Env): boolean {
  return env.SOCCER_INGEST_YESTERDAY === "1" || env.SOCCER_INGEST_YESTERDAY === "true";
}

/** Single competition+date ingestion: fetch once, upsert matches/teams/snapshots. Used by scoreboard and backfill. */
async function ingestOne(
  env: Env,
  competitionId: string,
  dateYmd: string,
  storeRawJson: boolean
): Promise<{ matchesUpserted: number; snapshotsInserted: number; teamsUpserted: number }> {
  const baseUrl = env.ESPN_SOCCER_BASE_URL.replace(/\/$/, "");
  try {
    const data = await fetchSoccerScoreboard(baseUrl, competitionId, dateYmd, SCOREBOARD_TIMEOUT_MS);
    const { matches, teams } = parseSoccerScoreboard(data, dateYmd, competitionId);

    const matchRows = matches.map((m) => ({
      match_id: m.matchId,
      competition_id: m.competitionId,
      date_ymd: m.dateYmd,
      start_time_utc: m.startTimeUtc,
      status: m.status,
      completed: m.completed ? 1 : 0,
      home_team_id: m.homeTeam.id,
      home_team_name: m.homeTeam.name,
      home_team_abbr: m.homeTeam.abbr,
      home_score: m.homeTeam.score,
      away_team_id: m.awayTeam.id,
      away_team_name: m.awayTeam.name,
      away_team_abbr: m.awayTeam.abbr,
      away_score: m.awayTeam.score,
      venue_name: m.venueName,
      neutral_site: m.neutralSite ? 1 : 0,
    }));

    await db.upsertSoccerMatchesCurrent(env.DB, matchRows);

    if (teams.length > 0) {
      await db.upsertSoccerTeamsBatch(
        env.DB,
        teams.map((t) => ({ team_id: t.teamId, name: t.name, abbr: t.abbr, logo: t.logo }))
      );
    }

    let snapshotsInserted = 0;
    if (matchRows.length > 0) {
      const snapshotRows = matchRows.map((m) => ({
        match_id: m.match_id,
        competition_id: m.competition_id,
        date_ymd: m.date_ymd,
        status: m.status ?? null,
        completed: m.completed,
        home_score: m.home_score,
        away_score: m.away_score,
        raw_json: storeRawJson ? JSON.stringify(data) : null,
      }));
      await db.insertSoccerMatchSnapshotsBatch(env.DB, snapshotRows);
      snapshotsInserted = snapshotRows.length;
    }

    return {
      matchesUpserted: matchRows.length,
      snapshotsInserted,
      teamsUpserted: teams.length,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new Error(msg);
  }
}

/**
 * Every-2-min cron: acquire lock, compute today in SOCCER_TZ, optionally yesterday (SOCCER_INGEST_YESTERDAY=1), ingest per competition.
 */
async function runScoreboardCron(env: Env): Promise<void> {
  const { acquired } = await db.acquireSoccerCronLock(env.DB, CRON_LOCK_TTL_SEC);
  if (!acquired) return;

  const runId = await db.insertSoccerCronRun(env.DB, "scoreboard", Math.floor(Date.now() / 1000));
  const tz = getTz(env);
  const baseUrl = env.ESPN_SOCCER_BASE_URL.replace(/\/$/, "");
  const competitions = getCompetitionsList(env);
  const storeRawJson = getDebugSnapshot(env);
  const ingestYesterday = getIngestYesterday(env);

  const datesToIngest: string[] = [todayYmdInTz(tz)];
  if (ingestYesterday) {
    datesToIngest.push(dateYmdDaysAgoInTz(1, tz));
  }

  let totalMatchesUpserted = 0;
  let totalSnapshotsInserted = 0;
  let totalTeamsUpserted = 0;
  let lastError: string | null = null;

  for (const competitionId of competitions) {
    for (const dateYmd of datesToIngest) {
      try {
        const r = await ingestOne(env, competitionId, dateYmd, storeRawJson);
        totalMatchesUpserted += r.matchesUpserted;
        totalSnapshotsInserted += r.snapshotsInserted;
        totalTeamsUpserted += r.teamsUpserted;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastError = msg;
        try {
          await db.insertSoccerErrorLog(env.DB, "scoreboard", competitionId, msg);
        } catch {
          // ignore
        }
      }
    }
  }

  try {
    await db.updateSoccerRefreshState(env.DB, {
      last_scoreboard_fetch_at: Math.floor(Date.now() / 1000),
      last_error: lastError,
    });
    await db.finishSoccerCronRun(env.DB, runId, {
      finished_at: Math.floor(Date.now() / 1000),
      ok: lastError == null ? 1 : 0,
      error: lastError,
      competitions_count: competitions.length,
      matches_upserted: totalMatchesUpserted,
      snapshots_inserted: totalSnapshotsInserted,
      teams_upserted: totalTeamsUpserted,
    });
  } catch {
    // ignore
  } finally {
    await db.releaseSoccerCronLock(env.DB);
  }
}

/**
 * Every-6h cron: upsert soccer_competitions from SOCCER_COMPETITIONS (active=1).
 */
async function runCompetitionMetadataCron(env: Env): Promise<void> {
  const runId = await db.insertSoccerCronRun(env.DB, "competition_metadata", Math.floor(Date.now() / 1000));
  const competitions = getCompetitionsList(env);
  const tierMap: Record<string, string> = {
    "eng.1": "domestic",
    "esp.1": "domestic",
    "ger.1": "domestic",
    "ita.1": "domestic",
    "fra.1": "domestic",
    "usa.1": "domestic",
    "uefa.champions": "international",
    "uefa.europa": "international",
    "uefa.euro": "international",
    "fifa.world": "international",
  };
  const rows = competitions.map((id) => ({
    competition_id: id,
    name: id,
    tier: tierMap[id] ?? "domestic",
    active: 1,
  }));
  try {
    await db.upsertSoccerCompetitions(env.DB, rows);
    await db.finishSoccerCronRun(env.DB, runId, {
      finished_at: Math.floor(Date.now() / 1000),
      ok: 1,
      competitions_count: rows.length,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    try {
      await db.insertSoccerErrorLog(env.DB, "competition_metadata", null, msg);
      await db.finishSoccerCronRun(env.DB, runId, {
        finished_at: Math.floor(Date.now() / 1000),
        ok: 0,
        error: msg,
      });
    } catch {
      // ignore
    }
  }
}

/**
 * 0 0 * * *: Cleanup snapshots older than SOCCER_SNAPSHOT_DAYS.
 */
async function runCleanupCron(env: Env): Promise<void> {
  const runId = await db.insertSoccerCronRun(env.DB, "cleanup", Math.floor(Date.now() / 1000));
  const retainDays = getSnapshotDays(env);
  try {
    const deleted = await db.cleanupSoccerSnapshots(env.DB, retainDays);
    await db.finishSoccerCronRun(env.DB, runId, {
      finished_at: Math.floor(Date.now() / 1000),
      ok: 1,
      snapshots_inserted: -deleted,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    try {
      await db.insertSoccerErrorLog(env.DB, "cleanup", null, msg);
      await db.finishSoccerCronRun(env.DB, runId, {
        finished_at: Math.floor(Date.now() / 1000),
        ok: 0,
        error: msg,
      });
    } catch {
      // ignore
    }
  }
}

/**
 * Daily backfill cron (0 3 * * *): ingest last SOCCER_BACKFILL_DAYS days per competition. Sequential; optional delay between ESPN calls.
 * CHANGED: If SOCCER_BACKFILL_END_YMD is set (valid YYYYMMDD), use it as end date and go backwards; else use today in SOCCER_TZ.
 */
async function runBackfillCron(env: Env): Promise<void> {
  const { acquired } = await db.acquireSoccerCronLock(env.DB, 3600);
  if (!acquired) return;

  const runId = await db.insertSoccerCronRun(env.DB, "backfill", Math.floor(Date.now() / 1000));
  const tz = getTz(env);
  let endYmd = getBackfillEndYmd(env) ?? todayYmdInTz(tz);
  if (parseYmdToUtcDate(endYmd) === null) endYmd = todayYmdInTz(tz); // CHANGED: fallback if invalid
  const days = getBackfillDays(env);
  const competitions = getCompetitionsList(env);
  const storeRawJson = getDebugSnapshot(env);

  let totalMatchesUpserted = 0;
  let totalSnapshotsInserted = 0;
  let totalTeamsUpserted = 0;
  let lastError: string | null = null;

  for (const competitionId of competitions) {
    for (let dayOffset = 0; dayOffset < days; dayOffset++) {
      const dateYmd = dateYmdDaysAgoFromEndYmd(endYmd, dayOffset); // CHANGED: from endYmd backwards
      try {
        const r = await ingestOne(env, competitionId, dateYmd, storeRawJson);
        totalMatchesUpserted += r.matchesUpserted;
        totalSnapshotsInserted += r.snapshotsInserted;
        totalTeamsUpserted += r.teamsUpserted;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastError = msg;
        try {
          await db.insertSoccerErrorLog(env.DB, "backfill", `${competitionId}:${dateYmd}`, msg);
        } catch {
          // ignore
        }
      }
      if (BACKFILL_DELAY_MS > 0) {
        await new Promise((r) => setTimeout(r, BACKFILL_DELAY_MS));
      }
    }
  }

  try {
    if (lastError) {
      await db.updateSoccerRefreshState(env.DB, { last_error: lastError });
    }
    await db.finishSoccerCronRun(env.DB, runId, {
      finished_at: Math.floor(Date.now() / 1000),
      ok: lastError == null ? 1 : 0,
      error: lastError,
      competitions_count: competitions.length,
      matches_upserted: totalMatchesUpserted,
      snapshots_inserted: totalSnapshotsInserted,
      teams_upserted: totalTeamsUpserted,
    });
  } catch {
    // ignore
  } finally {
    await db.releaseSoccerCronLock(env.DB);
  }
}

/**
 * Cron handler: dispatch by cron type.
 */
export async function handleScheduled(env: Env, event: ScheduledEvent): Promise<void> {
  const cron = event.cron ?? "";
  try {
    if (cron === "*/2 * * * *") {
      await runScoreboardCron(env);
    } else if (cron === "0 */6 * * *") {
      await runCompetitionMetadataCron(env);
    } else if (cron === "0 0 * * *") {
      await runCleanupCron(env);
    } else if (cron === "0 3 * * *") {
      await runBackfillCron(env);
    }
  } catch {
    // best-effort; do not rethrow
  }
}

/**
 * Force run scoreboard (admin): same as every-2-min cron logic; optionally includes yesterday if SOCCER_INGEST_YESTERDAY=1.
 */
export async function runScoreboardRefresh(env: Env): Promise<{
  dateYmd: string;
  competitionsCount: number;
  matchesUpserted: number;
  snapshotsInserted: number;
  teamsUpserted: number;
  error?: string;
}> {
  const tz = getTz(env);
  const dateYmd = todayYmdInTz(tz);
  const competitions = getCompetitionsList(env);
  const storeRawJson = getDebugSnapshot(env);
  const ingestYesterday = getIngestYesterday(env);

  const datesToIngest: string[] = [dateYmd];
  if (ingestYesterday) {
    datesToIngest.push(dateYmdDaysAgoInTz(1, tz));
  }

  let totalMatchesUpserted = 0;
  let totalSnapshotsInserted = 0;
  let totalTeamsUpserted = 0;
  let lastError: string | undefined;

  for (const competitionId of competitions) {
    for (const d of datesToIngest) {
      try {
        const r = await ingestOne(env, competitionId, d, storeRawJson);
        totalMatchesUpserted += r.matchesUpserted;
        totalSnapshotsInserted += r.snapshotsInserted;
        totalTeamsUpserted += r.teamsUpserted;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastError = msg;
        try {
          await db.insertSoccerErrorLog(env.DB, "scoreboard", competitionId, msg);
        } catch {
          // ignore
        }
      }
    }
  }

  await db.updateSoccerRefreshState(env.DB, {
    last_scoreboard_fetch_at: Math.floor(Date.now() / 1000),
    last_error: lastError ?? null,
  });

  return {
    dateYmd,
    competitionsCount: competitions.length,
    matchesUpserted: totalMatchesUpserted,
    snapshotsInserted: totalSnapshotsInserted,
    teamsUpserted: totalTeamsUpserted,
    ...(lastError && { error: lastError }),
  };
}

/**
 * Manual admin backfill: ingest last N days for one or all competitions. Sequential with small delay.
 * CHANGED: optional endYmd (YYYYMMDD); if provided, backfill from endYmd backwards; else from today in TZ.
 */
export async function runBackfillOnce(
  env: Env,
  days: number,
  competitionIdFilter?: string,
  endYmd?: string
): Promise<{
  days: number;
  competitionsCount: number;
  matchesUpserted: number;
  snapshotsInserted: number;
  teamsUpserted: number;
  error?: string;
}> {
  const tz = getTz(env);
  const endYmdResolved = endYmd != null && endYmd !== "" ? endYmd : todayYmdInTz(tz); // CHANGED: endYmd param
  const competitions = competitionIdFilter
    ? [competitionIdFilter]
    : getCompetitionsList(env);
  const storeRawJson = getDebugSnapshot(env);
  const clampedDays = Math.max(1, Math.min(120, days));

  let totalMatchesUpserted = 0;
  let totalSnapshotsInserted = 0;
  let totalTeamsUpserted = 0;
  let lastError: string | undefined;

  for (const competitionId of competitions) {
    for (let dayOffset = 0; dayOffset < clampedDays; dayOffset++) {
      const dateYmd = dateYmdDaysAgoFromEndYmd(endYmdResolved, dayOffset); // CHANGED: from endYmd backwards
      try {
        const r = await ingestOne(env, competitionId, dateYmd, storeRawJson);
        totalMatchesUpserted += r.matchesUpserted;
        totalSnapshotsInserted += r.snapshotsInserted;
        totalTeamsUpserted += r.teamsUpserted;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastError = msg;
        try {
          await db.insertSoccerErrorLog(env.DB, "backfill", `${competitionId}:${dateYmd}`, msg);
        } catch {
          // ignore
        }
      }
      if (BACKFILL_DELAY_MS > 0) {
        await new Promise((r) => setTimeout(r, BACKFILL_DELAY_MS));
      }
    }
  }

  return {
    days: clampedDays,
    competitionsCount: competitions.length,
    matchesUpserted: totalMatchesUpserted,
    snapshotsInserted: totalSnapshotsInserted,
    teamsUpserted: totalTeamsUpserted,
    ...(lastError && { error: lastError }),
  };
}

export { FORM_LAST_N, getBackfillDays };
