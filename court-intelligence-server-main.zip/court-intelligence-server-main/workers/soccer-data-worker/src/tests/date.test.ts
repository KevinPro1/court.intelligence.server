import { describe, it, expect } from "vitest";
import {
  todayYmdInTz,
  todayYmdEastern,
  dateYmdDaysAgoInTz,
  dateYmdDaysAheadInTz,
  dateYmdDaysAgoFromEndYmd,
  parseYmdToUtcDate,
  ymdFromUtcDate,
} from "../utils/date"; // CHANGED: backfill endYmd utils

const NY = "America/New_York";
const UTC_TZ = "UTC";

describe("todayYmdInTz (timezone correctness)", () => {
  it("returns YYYYMMDD string", () => {
    const s = todayYmdInTz(NY);
    expect(s).toMatch(/^\d{8}$/);
    expect(s.length).toBe(8);
  });

  it("America/New_York: late night ET is still same calendar day", () => {
    // 2024-01-01 22:00:00 ET = 2024-01-02 03:00:00 UTC -> "today" in NY is 20240101
    const d = new Date("2024-01-02T03:00:00Z");
    expect(todayYmdInTz(NY, d)).toBe("20240101");
  });

  it("America/New_York: early morning ET is next calendar day in NY", () => {
    // 2024-01-02 01:00:00 ET = 2024-01-02 06:00:00 UTC -> 20240102
    const d = new Date("2024-01-02T06:00:00Z");
    expect(todayYmdInTz(NY, d)).toBe("20240102");
  });

  it("America/New_York: around UTC midnight (ET still previous day)", () => {
    // 2024-01-02 00:00:00 UTC = 2024-01-01 19:00:00 ET
    const d = new Date("2024-01-02T00:00:00Z");
    expect(todayYmdInTz(NY, d)).toBe("20240101");
  });

  it("UTC vs NY difference: same instant, different calendar day", () => {
    // 2024-01-02 00:30:00 UTC -> in UTC it's 20240102, in NY (Jan 1 19:30) it's 20240101
    const d = new Date("2024-01-02T00:30:00Z");
    expect(todayYmdInTz(UTC_TZ, d)).toBe("20240102");
    expect(todayYmdInTz(NY, d)).toBe("20240101");
  });

  it("UTC: midnight UTC is 20240102", () => {
    const d = new Date("2024-01-02T00:00:00Z");
    expect(todayYmdInTz(UTC_TZ, d)).toBe("20240102");
  });

  it("todayYmdEastern defaults to America/New_York", () => {
    const d = new Date("2024-01-02T03:00:00Z");
    expect(todayYmdEastern(d)).toBe("20240101");
  });
});

describe("dateYmdDaysAgoInTz / dateYmdDaysAheadInTz", () => {
  it("dateYmdDaysAgoInTz subtraction", () => {
    const d = new Date("2024-01-15T12:00:00Z");
    expect(dateYmdDaysAgoInTz(14, NY, d)).toBe("20240101");
  });

  it("dateYmdDaysAheadInTz addition", () => {
    const d = new Date("2024-01-15T12:00:00Z");
    expect(dateYmdDaysAheadInTz(1, NY, d)).toBe("20240116");
  });

  it("todayYmdInTz: 2025-02-17 01:00 UTC is 2025-02-16 in NY (8pm prev day)", () => {
    const d = new Date("2025-02-17T01:00:00.000Z");
    expect(todayYmdInTz(NY, d)).toBe("20250216");
  });

  it("todayYmdInTz: 2025-02-17 06:00 UTC is 2025-02-17 in NY (1am ET)", () => {
    const d = new Date("2025-02-17T06:00:00.000Z");
    expect(todayYmdInTz(NY, d)).toBe("20250217");
  });

  it("dateYmdDaysAgoInTz(1, NY, fixedNow) equals yesterday in that TZ", () => {
    const fixedNow = new Date("2025-02-17T12:00:00.000Z");
    const yesterday = dateYmdDaysAgoInTz(1, NY, fixedNow);
    expect(yesterday).toBe("20250216");
  });
});

// CHANGED: backfill endYmd pure functions
describe("dateYmdDaysAgoFromEndYmd", () => {
  it("daysAgo=0 returns endYmd", () => {
    expect(dateYmdDaysAgoFromEndYmd("20250215", 0)).toBe("20250215");
  });
  it("daysAgo=1 returns previous day", () => {
    expect(dateYmdDaysAgoFromEndYmd("20250215", 1)).toBe("20250214");
  });
  it("cross month: 20250301 - 1 day = 20250228", () => {
    expect(dateYmdDaysAgoFromEndYmd("20250301", 1)).toBe("20250228");
  });
  it("leap year: 20240301 - 1 day = 20240229", () => {
    expect(dateYmdDaysAgoFromEndYmd("20240301", 1)).toBe("20240229");
  });
});

describe("parseYmdToUtcDate / ymdFromUtcDate", () => {
  it("parseYmdToUtcDate valid returns Date, ymdFromUtcDate round-trips", () => {
    const d = parseYmdToUtcDate("20250215");
    expect(d).not.toBeNull();
    expect(ymdFromUtcDate(d!)).toBe("20250215");
  });
  it("parseYmdToUtcDate invalid returns null", () => {
    expect(parseYmdToUtcDate("20250230")).toBeNull();
    expect(parseYmdToUtcDate("")).toBeNull();
    expect(parseYmdToUtcDate("1234567")).toBeNull();
  });
});
