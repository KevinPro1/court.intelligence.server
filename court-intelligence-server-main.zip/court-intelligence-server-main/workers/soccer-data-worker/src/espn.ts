/**
 * ESPN Soccer API fetch and parse (multi-competition).
 * Defensive parsing; competition passed by caller.
 */

import type { NormalizedSoccerMatch, NormalizedSoccerTeam } from "./types";

const DEFAULT_TIMEOUT_MS = 6000;

function safeStr(v: unknown): string {
  if (v == null) return "";
  return String(v);
}

function safeNum(v: unknown, def: number): number {
  if (v == null) return def;
  const n = Number(v);
  return isNaN(n) ? def : n;
}

/**
 * Build scoreboard URL.
 * GET {baseUrl}/{competitionId}/scoreboard?dates=YYYYMMDD
 */
export function getSoccerScoreboardUrl(
  baseUrl: string,
  competitionId: string,
  dateYmd: string
): string {
  const base = baseUrl.replace(/\/$/, "");
  return `${base}/${competitionId}/scoreboard?dates=${dateYmd}`;
}

/**
 * Fetch scoreboard for one competition and date.
 */
export async function fetchSoccerScoreboard(
  baseUrl: string,
  competitionId: string,
  dateYmd: string,
  timeoutMs: number = DEFAULT_TIMEOUT_MS
): Promise<unknown> {
  const url = getSoccerScoreboardUrl(baseUrl, competitionId, dateYmd);
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    clearTimeout(timeoutId);
    if (!res.ok) throw new Error(`ESPN soccer scoreboard: ${res.status}`);
    return (await res.json()) as unknown;
  } catch (e) {
    clearTimeout(timeoutId);
    throw e;
  }
}

/** ESPN competitor (defensive). */
interface SoccerEventCompetitor {
  id?: string;
  homeAway?: string;
  score?: string;
  team?: {
    id?: string;
    displayName?: string;
    name?: string;
    abbreviation?: string;
    logo?: string;
  };
}

/** ESPN competition (venue, status). */
interface SoccerEventCompetition {
  competitors?: SoccerEventCompetitor[];
  status?: {
    type?: { completed?: boolean; detail?: string; state?: string; name?: string; shortDetail?: string };
    displayClock?: string;
    period?: number;
  };
  venue?: { fullName?: string; neutralSite?: boolean };
}

interface SoccerEvent {
  id?: string;
  date?: string;
  name?: string;
  competitions?: SoccerEventCompetition[];
  competitors?: SoccerEventCompetitor[];
}

function getTeamFromCompetitor(c: SoccerEventCompetitor): NormalizedSoccerTeam {
  const team = c?.team;
  const id = safeStr(team?.id ?? (c as { id?: string }).id);
  const name = safeStr(team?.displayName ?? team?.name ?? id);
  const abbr = safeStr(team?.abbreviation ?? id);
  const logo = team?.logo != null ? safeStr(team.logo) : null;
  return { teamId: id, name, abbr, logo: logo || null };
}

function getScore(c: SoccerEventCompetitor): number {
  const s = c?.score;
  if (s == null) return 0;
  const n = parseInt(String(s), 10);
  return isNaN(n) ? 0 : n;
}

/**
 * Parse soccer scoreboard JSON into normalized matches + teams.
 * Uses competitionId for each match; extracts venue from first competition.
 */
export function parseSoccerScoreboard(
  json: unknown,
  dateYmd: string,
  competitionId: string
): { matches: NormalizedSoccerMatch[]; teams: NormalizedSoccerTeam[] } {
  const matches: NormalizedSoccerMatch[] = [];
  const teamMap = new Map<string, NormalizedSoccerTeam>();
  try {
    const root = json as Record<string, unknown>;
    const events = (root?.events as SoccerEvent[] | undefined) ?? [];
    for (const ev of events) {
      const id = safeStr(ev?.id);
      if (!id) continue;
      const comps = ev?.competitions ?? [];
      const comp = comps[0];
      const rawCompetitors =
        comp?.competitors ?? (ev?.competitors as SoccerEventCompetitor[] | undefined) ?? [];
      const home = rawCompetitors.find((c) => String(c?.homeAway).toLowerCase() === "home");
      const away = rawCompetitors.find((c) => String(c?.homeAway).toLowerCase() === "away");
      const status = comp?.status;
      const completed = status?.type?.completed === true;
      const statusDisplay =
        safeStr(status?.type?.shortDetail) ||
        safeStr(status?.type?.detail) ||
        safeStr(status?.type?.name) ||
        safeStr(status?.type?.state) ||
        "scheduled";

      let startTimeUtc: string | null = null;
      if (ev?.date) {
        try {
          startTimeUtc = new Date(String(ev.date)).toISOString();
        } catch {
          startTimeUtc = safeStr(ev.date);
        }
      }
      const dateFromEvent = ev?.date
        ? String(ev.date).slice(0, 10).replace(/-/g, "")
        : dateYmd;

      const homeTeam = getTeamFromCompetitor(home ?? {});
      const awayTeam = getTeamFromCompetitor(away ?? {});
      teamMap.set(homeTeam.teamId, homeTeam);
      teamMap.set(awayTeam.teamId, awayTeam);

      const venue = comp?.venue;
      const venueName = venue?.fullName != null ? safeStr(venue.fullName) : null;
      const neutralSite = venue?.neutralSite === true;

      matches.push({
        matchId: id,
        competitionId,
        dateYmd: dateFromEvent || dateYmd,
        startTimeUtc,
        status: statusDisplay,
        completed,
        homeTeam: { id: homeTeam.teamId, name: homeTeam.name, abbr: homeTeam.abbr, score: getScore(home ?? {}) },
        awayTeam: { id: awayTeam.teamId, name: awayTeam.name, abbr: awayTeam.abbr, score: getScore(away ?? {}) },
        venueName: venueName || null,
        neutralSite,
      });
    }
  } catch {
    // defensive
  }
  return { matches, teams: Array.from(teamMap.values()) };
}
