/**
 * Date and timezone utilities for Soccer Data Worker.
 * "Today" is computed in SOCCER_TZ (default America/New_York).
 */

const DEFAULT_TZ = "America/New_York";

/**
 * Get "today" as YYYYMMDD string in the given timezone.
 * @param tz IANA timezone (e.g. America/New_York). Default America/New_York.
 * @param now Optional Date (default: Date.now()).
 */
export function todayYmdInTz(tz: string = DEFAULT_TZ, now: Date = new Date()): string {
  const s = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  return s.replace(/-/g, "");
}

/**
 * Alias for America/New_York (backward compat).
 */
export function todayYmdEastern(now: Date = new Date()): string {
  return todayYmdInTz(DEFAULT_TZ, now);
}

/**
 * Get N days ago as YYYYMMDD in the given timezone.
 */
export function dateYmdDaysAgoInTz(
  days: number,
  tz: string = DEFAULT_TZ,
  now: Date = new Date()
): string {
  const d = new Date(now.getTime() - days * 86400 * 1000);
  return todayYmdInTz(tz, d);
}

/**
 * Get N days ahead as YYYYMMDD in the given timezone.
 */
export function dateYmdDaysAheadInTz(
  days: number,
  tz: string = DEFAULT_TZ,
  now: Date = new Date()
): string {
  const d = new Date(now.getTime() + days * 86400 * 1000);
  return todayYmdInTz(tz, d);
}

// CHANGED: pure UTC helpers for backfill endYmd (no tz)

/**
 * Parse "YYYYMMDD" to a UTC Date. Returns null for invalid ymd (wrong length, non-digits, or invalid calendar date).
 */
export function parseYmdToUtcDate(ymd: string): Date | null {
  if (typeof ymd !== "string" || ymd.length !== 8 || !/^\d{8}$/.test(ymd)) return null;
  const year = parseInt(ymd.slice(0, 4), 10);
  const month = parseInt(ymd.slice(4, 6), 10);
  const day = parseInt(ymd.slice(6, 8), 10);
  if (month < 1 || month > 12) return null;
  const d = new Date(Date.UTC(year, month - 1, day));
  if (d.getUTCFullYear() !== year || d.getUTCMonth() !== month - 1 || d.getUTCDate() !== day) return null;
  return d;
}

/**
 * Format a Date to YYYYMMDD in UTC.
 */
export function ymdFromUtcDate(d: Date): string {
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth() + 1;
  const day = d.getUTCDate();
  const ys = String(y);
  const ms = m < 10 ? "0" + m : String(m);
  const ds = day < 10 ? "0" + day : String(day);
  return ys + ms + ds;
}

/**
 * From endYmd (YYYYMMDD), return the date N days ago (day-level only, UTC). daysAgo=0 returns endYmd.
 * Invalid endYmd throws (caller should validate with /^\d{8}$/ or parseYmdToUtcDate).
 */
export function dateYmdDaysAgoFromEndYmd(endYmd: string, daysAgo: number): string {
  const d = parseYmdToUtcDate(endYmd);
  if (d == null) throw new Error(`Invalid endYmd: ${endYmd}`);
  if (!Number.isFinite(daysAgo) || daysAgo < 0) throw new Error(`Invalid daysAgo: ${daysAgo}`);
  const ms = d.getTime() - daysAgo * 86400 * 1000;
  return ymdFromUtcDate(new Date(ms));
}
