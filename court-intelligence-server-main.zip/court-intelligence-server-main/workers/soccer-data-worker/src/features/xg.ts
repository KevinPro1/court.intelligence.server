/**
 * Baseline xG (expected goals) - simple deterministic heuristic.
 * If x,y available: distance + angle -> logistic approx.
 * Else: fallback buckets (penalty, header, open_play, etc.).
 */

/** Goal mouth: center at (1, 0.5), width ~0.2, height ~0.44 (normalized 0-1 pitch). */
const GOAL_CENTER_X = 1.0;
const GOAL_CENTER_Y = 0.5;

function sigmoid(z: number): number {
  if (z >= 20) return 1;
  if (z <= -20) return 0;
  return 1 / (1 + Math.exp(-z));
}

/**
 * Distance from (x,y) to goal center (normalized 0-1 pitch, goal at x=1).
 */
function distanceToGoal(x: number, y: number): number {
  const dx = GOAL_CENTER_X - x;
  const dy = GOAL_CENTER_Y - y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Angle to goal in radians (from shooter position). Simplified: angle from (x,y) to goal center.
 */
function angleToGoal(x: number, y: number): number {
  const dx = GOAL_CENTER_X - x;
  const dy = GOAL_CENTER_Y - y;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist < 1e-6) return Math.PI / 2;
  return Math.acos(Math.min(1, Math.max(-1, dx / dist)));
}

/**
 * Baseline xG from coordinates (normalized 0-1).
 * xg = sigmoid(a + b*distance + c*angle). Tuned so ~0.1 from far, ~0.7 from close.
 */
export function xgFromCoordinates(x: number, y: number): number {
  const dist = distanceToGoal(x, y);
  const angle = angleToGoal(x, y);
  const a = 2.5;
  const b = -3;
  const c = 2;
  const z = a + b * dist + c * angle;
  return Math.round(sigmoid(z) * 100) / 100;
}

/**
 * Fallback xG from shot_type / situation (no coords).
 */
export function xgFromShotType(situation: string, shotType: string, isPenalty: boolean): number {
  const sit = (situation || "").toLowerCase();
  const type = (shotType || "").toLowerCase();
  if (isPenalty || sit.includes("penalty") || type.includes("penalty")) return 0.76;
  if (type.includes("header") || sit.includes("header")) return 0.1;
  if (type.includes("goal") && type.includes("header")) return 0.1;
  if (sit.includes("set_piece") || sit.includes("set piece")) return 0.12;
  return 0.12;
}

/**
 * Compute xG for a shot. Prefer coords if both x and y are present and valid.
 */
export function computeXg(
  x: number | null,
  y: number | null,
  situation: string,
  shotType: string,
  isPenalty: boolean = false
): number {
  if (
    x != null &&
    y != null &&
    Number.isFinite(x) &&
    Number.isFinite(y) &&
    x >= 0 &&
    x <= 1 &&
    y >= 0 &&
    y <= 1
  ) {
    return xgFromCoordinates(x, y);
  }
  return xgFromShotType(situation, shotType, isPenalty);
}
